import java.util.Scanner;
public class Main {
	public static void main(String[]args) {
		Scanner input=new Scanner (system.in);
		//Single-dimensional arrays String[] products= {
		"Cozy Nights Monarch"
		"Restonic Barbados"
		"Sealy Phuket"

		//Two-dimensional array int[][] sals=new int
		//Enter sales for each product for (int i=0;i<products.length;i++) {
		for(int j+0:j<3; j++) {
			System.out.print("Enter number of sales for month");
			sales[i][j] = input.nextInt();

			System.out.println();
		}
		//Create Product Object
		Product product = new Products(products.sales);

		//Create PrintProduct object
		PrintProduct report= new PrintProduct

		//Display report
		system.out.println("\nPRODUCT SALES REPORT-2026");

		report.PrintTotalSales();
		report.PrintAverageSales();
		report.PrintMostPopularProduct();

		input.close();
	}
}