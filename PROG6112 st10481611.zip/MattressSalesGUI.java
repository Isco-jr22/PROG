import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MattressSalesGUI extends JFrame {
    
    JTextField customer = new JTextField();
    JTextField product = new JTextField();
    JTextField price = new JTextField();
    
    DefaultTableModel model = new DefaultTableModel(new String[]{"Customer","Product","VAT","Commission","Total"}, 0);
    public MattressSalesGUI() {
        setTitle("Mattress Sales System");
        setSize(750,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        JPanel panel = new JPanel(new GridLayout(4,2,5,5));
        
        panel.add(new JLabel("CustomerName:"));
        panel.add(customer);
        
        panel.add(new JLabel("Product name"));
        panel.add(product);
        
        panel.add(new JLabel("Product Price"));
        panel.add(price);
        
        JButton calculate = new JButton("Calculate Sale");
        JButton clear = new JButton("Clear");
        
        panel.add(calculate);
        panel.add(clear);
        
        add(panel,BorderLayout.NORTH);
        add(new JScrollPanel(new JTable))
        
        calculate.addActionListener
    }
    public void calculateSale() {
        try {
            String name = customer.getText();
            String item = product.getText();
            double p = Double.parseDouble(price.getText());
            if (name.isEmpty()|| item.isEmpty() || p<=0) {
                
            }
        }
    }
}