public class PrintProduct {
    private Product product;
    
    public PrintProduct(Product product) {
        this .product = product;
    }
    
    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES:"+product.getTotalSales());
        
    }
    
    public void printAverageProductSales() {
        System.out.println("AverageProductSales"+product.getAverageSales());
        
    }
    
    public void printMostPoularProductSale() {
        System.out.println("MOST POPULAR PRODUCT:"+product.getMostPopularProduct());
        
    }
}