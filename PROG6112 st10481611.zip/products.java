public interface IProducts {
    int getTotalSales();
    int getAverageSales();
    String getMostPopularProduct();
}